"""Editable academic report source."""
